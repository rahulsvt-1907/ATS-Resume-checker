import streamlit as st
import google.generativeai as genai
import os
import PyPDF2 as pdf
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer, util

load_dotenv()  # Load environment variables
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

# Sample Fashion Database
fashion_database = {
    "Casual": "Comfortable and stylish outfits including jeans, t-shirts, sneakers, and hoodies.",
    "Formal": "Elegant attire such as suits, dress shirts, ties, and dress shoes.",
    "Streetwear": "Trendy street fashion including oversized shirts, ripped jeans, and sneakers.",
    "Traditional": "Ethnic wear like sarees, kurtas, ethnic jackets, and mojris."
}

# Gemini Pro Response
def get_gemini_response(input):
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(input)
    return response.text

def input_pdf_text(uploaded_file):
    reader = pdf.PdfReader(uploaded_file)
    text = ""
    for page in range(len(reader.pages)):
        page = reader.pages[page]
        text += str(page.extract_text())
    return text

# Function to Match Fashion Preferences with Database
def match_fashion_preferences(user_text):
    model = SentenceTransformer('paraphrase-MiniLM-L6-v2')
    user_embedding = model.encode(user_text)

    matched_styles = []
    for style, description in fashion_database.items():
        style_embedding = model.encode(description)
        similarity_score = util.pytorch_cos_sim(user_embedding, style_embedding)[0][0].item()
        matched_styles.append({"style": style, "similarity_score": similarity_score * 100})

    return matched_styles

# Streamlit app
st.title("Fashion Stylish AI")
st.text("Get A Different Style")
user_requirements = st.text_area("Enter Your Fashion Preferences")
uploaded_file = st.file_uploader("Upload Your Fashion Document (PDF)", type="pdf", help="Please upload a PDF document describing your style preferences.")
submit = st.button("Submit")

# Prompt Template
input_prompt = """
You are an expert fashion stylist AI. Your task is to analyze the user's fashion preferences and recommend personalized outfits.

1. **User Input (Preferences from PDF)**: {text}

Please provide recommendations in a structured JSON format:
{{"Recommended Styles": [], "Suggested Outfits": ""}}
"""

if submit:
    if uploaded_file is not None:
        # Extract text from PDF
        text = input_pdf_text(uploaded_file)

        # Match preferences with fashion database
        matched_styles = match_fashion_preferences(text)
        st.subheader("Suitable Fashion Styles:")
        for match in matched_styles:
            st.write(f"{match['style']}: {match['similarity_score']:.2f}% match")

        # Display the most relevant style
        if matched_styles:
            best_match = max(matched_styles, key=lambda x: x['similarity_score'])
            st.subheader(f"Recommended Style: {best_match['style']} ({best_match['similarity_score']:.2f}% match)")

        # Generate response using Gemini Pro
        response = get_gemini_response(input_prompt.format(text=text))
        st.subheader("AI Fashion Recommendation:")
        st.write(response)
