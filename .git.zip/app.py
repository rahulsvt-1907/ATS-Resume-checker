import streamlit as st 
import google.generativeai as genai
import os
import PyPDF2 as pdf
from dotenv import load_dotenv
import json
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load environment variables
load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

def get_gemini_response(input):
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(input)
    return response.text

def input_pdf_text(uploaded_file):
    reader = pdf.PdfReader(uploaded_file)
    text = ""
    for page in range(len(reader.pages)):
        page = reader.pages[page]
        text += str(page.extract_text())
    return text

def get_fashion_recommendations(user_text, num_recommendations=3):
    # Sample fashion database
    FASHION_DATABASE = {
        "Casual": "Jeans, T-shirts, Sneakers, Hoodies, Jackets",
        "Formal": "Suits, Dress Shirts, Leather Shoes, Ties, Blazers",
        "Streetwear": "Oversized T-Shirts, Ripped Jeans, Sneakers, Caps",
        "Traditional": "Sarees, Kurtas, Ethnic Jackets, Mojaris"
    }
    
    vectorizer = TfidfVectorizer(stop_words='english')
    fashion_styles = list(FASHION_DATABASE.keys())
    fashion_texts = list(FASHION_DATABASE.values())
    
    all_texts = fashion_texts + [user_text]
    tfidf_matrix = vectorizer.fit_transform(all_texts)
    
    similarity_scores = cosine_similarity(tfidf_matrix[-1:], tfidf_matrix[:-1])[0]
    top_indices = similarity_scores.argsort()[-num_recommendations:][::-1]
    
    recommendations = []
    for idx in top_indices:
        recommendations.append({
            'style': fashion_styles[idx],
            'outfit_suggestions': FASHION_DATABASE[fashion_styles[idx]],
            'match_percentage': similarity_scores[idx] * 100
        })
    
    return recommendations

input_prompt = """
You are an advanced AI Fashion Stylist. Your task is to analyze the user's fashion preferences from the given text
and provide personalized fashion recommendations.

1. **User Input (Preferences from PDF)**: {text}
2. **User Desired Outfit Style**: {user_style}

Please provide recommendations in a structured JSON format:
{{"Recommended Styles": [], "Suggested Outfits": ""}}
"""

# Streamlit UI
st.title("Fashion Stylish AI")
st.text("Discover Your Unique Style!")

tab1, tab2 = st.tabs(["Fashion Analysis", "Style Recommendations"])

text = ""  # Initialize text variable
with tab1:
    uploaded_file = st.file_uploader("Upload Your Fashion Preference Document (PDF)", type="pdf")
    user_style = st.text_area("How do you want to be dressed?")
    submit = st.button("Analyze")

    if submit and uploaded_file is not None:
        text = input_pdf_text(uploaded_file)
        formatted_prompt = input_prompt.format(text=text, user_style=user_style)
        response = get_gemini_response(formatted_prompt)

        try:
            response_data = json.loads(response)
            recommended_styles = response_data.get("Recommended Styles", [])
            suggested_outfits = response_data.get("Suggested Outfits", "")
            
            st.subheader("AI Fashion Analysis Results")
            st.write(f"**Recommended Styles:** {', '.join(recommended_styles) if recommended_styles else 'Not found'}")
            st.write(f"**Suggested Outfits:** {suggested_outfits}")

        except (json.JSONDecodeError, ValueError) as e:
            st.error("Error parsing the response. Please try again.")

with tab2:
    if text:  # Ensure text is defined before using it
        fashion_recommendations = get_fashion_recommendations(text)
        st.subheader("Personalized Outfit Recommendations")
        for recommendation in fashion_recommendations:
            st.write(f"**Style:** {recommendation['style']}")
            st.write(f"**Outfit Suggestions:** {recommendation['outfit_suggestions']}")
            st.write(f"**Match Percentage:** {recommendation['match_percentage']:.2f}%")
            st.write("---")
